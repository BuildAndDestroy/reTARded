#!/bin/bash

if [ $(id -u) != 0 ];  # User Must be Root
  then
	echo "Please run as root"
	exit
fi

if [ $(cat /proc/version | grep -ci kali) -ge 1 ];  # Verify Linux is Kali
  then
	#echo "Pass as Kali"
	nextRun=(/bin /boot /etc /home /lib /lib64 /opt /root /run /sbin /srv /sys /usr /var)
elif [ $(cat /proc/version | grep -ci centos) -ge 1 ];  # Verify Linux is CentOS
  then
	#echo "Pass as Centos"
	nextRun=(/bin /boot /dev /etc /home /lib /lib64 /media /opt /root /run /sbin /srv /usr /var)
elif [ $(cat /proc/version | grep -ci ubuntu) -ge 1 ];  # Verify Linux is Ubuntu
  then
	#echo "Pass as Ubuntu"
	nextRun=(/bin /boot /etc /home /lib /lib64 /opt /root /run /sbin /srv /sys /usr /var)
else
	echo "This version is currently not supported"
	exit
fi

clear

###########################################################################

toDay=$(date +"%F")

for i in "${nextRun[@]}";
do
	echo "Backing up $i content, please wait.."
	#echo $i
	tar -zcf /.snapshots$i.$toDay.tar.gz $i/* 2> /dev/null
	echo "Moving to '/.snapshots/Backups' directory, please wait.."
	mv /.snapshots/$i* /.snapshots/Backups/ 
	printf '%s\n'
	printf '%s\n'
done


clear

echo 'Would you like to move to the NAS? (y/n)'
read -r -p '>>> ' remoteNAS

while [[ $remoteNAS != 'y' && $remoteNAS != 'n' ]]; do
    echo 'Please answer with a "y" or "n".'
    read -r -p '>>> ' remoteNAS
done

if [[ $remoteNAS == 'y' ]]; then
    echo 'Running an rsync to the NAS server, this may take time: '
    rsync -chavzP --stats /.snapshots/Backups/* /mnt/*/Backups/
    echo 'Backups are now on the NAS!'
fi

if [[ $remoteNAS == 'n' ]]; then
    echo 'Backups are stored in /.snapshots/Backups/'
fi

echo ""
echo "Created by Mitch O'Donnell"
