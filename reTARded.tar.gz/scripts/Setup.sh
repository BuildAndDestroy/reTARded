#!/bin/bash

clear

#########USER MUST BE ROOT##########

if [ $(id -u) != 0 ];
   then echo "Please run as root"
   exit
fi
###################################

echo "Creating /.snapshots directory"

mkdir /.snapshots
chown root:root /.snapshots
chmod 644 /.snapshots
printf '%s\n'

echo "Creating /.snapshots/Backups directory"

mkdir /.snapshots/Backups
chown root:root /.snapshots/Backups
chmod 644 /.snapshots/Backups
printf '%s\n'


echo "Creating /.snapshots/scripts directory"

mkdir /.snapshots/scripts
chown root:root /.snapshots/scripts
chmod 644 /.snapshots/scripts
printf '%s\n'

echo "Moving Files, please wait.."

mv reTARded.sh /.snapshots/scripts/
mv Setup.sh /.snapshots/scripts/
chown root:root /.snapshots/scripts/*
chmod 755 /.snapshots/scripts/*
printf '%s\n'

echo "Done moving. Please run /.snapshots/scripts/./reTARded.sh"

